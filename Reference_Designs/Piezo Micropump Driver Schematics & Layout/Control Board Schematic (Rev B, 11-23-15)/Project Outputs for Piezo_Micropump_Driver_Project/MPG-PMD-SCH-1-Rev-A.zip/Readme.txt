------------------------------------------------------------------------------------------
Gerber File Extension Report For: Control_Board.GBR   11/4/2015  4:43:17 PM
------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------
Layer Extension     Layer Description                      
------------------------------------------------------------------------------------------
.GTL                Top Layer                               
.GBL                Bottom Layer                            
.GTO                Top Overlay                             
.GTS                Top Solder                              
.GBS                Bottom Solder                           
.GBO                Bottom Overlay                          
.GM32               Mechanical 32                           
.GD1                Drill Drawing                           
Control_Board-Plated.TXT		NC Drill Plated
Control_Board-NonPlated.TXT		NC Drill NonPlated
------------------------------------------------------------------------------------------
